package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import modelo.AnswersDAO;
import modelo.Survey;
import modelo.SurveyModelsDAO;
import modelo.SurveysDAO;
import utility.Utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;

/**
 * Servlet implementation class NewSurvey
 */
public class NewSurvey extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewSurvey() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SurveysDAO exDAO = new SurveysDAO();
		String todo = request.getParameter("operation");
		Logger.getLogger(this.getClass().getName()).log(Level.INFO, "Entro con operation "+todo, "");
		if (todo.equals("insert")){
			Survey surv = new Survey(Utilities.generateRandomString(6),Integer.parseInt(request.getParameter("survey_model")),request.getParameter("title"));
			exDAO.insert(surv);
		}else if (todo.equals("delete")) {
			exDAO.delete(request.getParameter("id"));
		}
		else {
			//TODO: Poner un log o algo
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
