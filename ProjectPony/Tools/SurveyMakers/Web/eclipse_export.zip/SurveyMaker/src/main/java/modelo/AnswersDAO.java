package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import utility.Utilities;

public class AnswersDAO {
	
	private DataSource ds = null;

	public AnswersDAO() {
		InitialContext initContext;
		try {
			initContext = new InitialContext();
			ds = (DataSource) initContext.lookup("java:/comp/env/jdbc/SurveyMakerDB");
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
	}
	
	public int insert(Answer response) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("INSERT INTO answers (survey, fill_date, data) VALUES (?,?,?)");
			ps.setString(1, response.getSurvey());
			ps.setDate(2, response.getFill_date());
			ps.setString(3, Utilities.implode(response.getData(),"::"));
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
	
	public int update(Answer response) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("UPDATE answers SET survey = ?, fill_date = ?, data = ? WHERE id = ?");
			ps.setString(1, response.getSurvey());
			ps.setDate(2, response.getFill_date());
			ps.setString(3, Utilities.implode(response.getData(),"::"));
			ps.setInt(4, response.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
    
	public int delete(Answer response) {
    	int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("DELETE FROM answers WHERE id = ?");
			ps.setInt(1, response.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
    }
	
    public Answer read (int id) {
    	Answer result = null;
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM answers WHERE id=?");
    		ps.setInt(1, id);
    		ResultSet rs = ps.executeQuery();
    		if (rs.next()) {
    			result = new Answer(rs.getInt("id"), rs.getString("survey"),rs.getDate("fill_date"),Utilities.explode(rs.getString("data"),"::"));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public int getAnswersToSurvey (String id) {
    	int result = 0;
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM answers WHERE survey=?");
    		ps.setString(1, id);
    		ResultSet rs = ps.executeQuery();
    		while (rs.next()) {
    			result +=1;
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public ArrayList<Answer> readFromSurvey (String id) {
    	ArrayList<Answer> result = new ArrayList<>();
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM answers WHERE survey=?");
    		ps.setString(1, id);
    		ResultSet rs = ps.executeQuery();
    		while (rs.next()) {
    			result.add(new Answer(rs.getInt("id"), rs.getString("survey"),rs.getDate("fill_date"),Utilities.explode(rs.getString("data"),"::")));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public ArrayList<Answer> readAll () {
    	ArrayList<Answer> result = new ArrayList<>();
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM answers");
    		ResultSet rs = ps.executeQuery();
    		while (rs.next()) {
    			result.add(new Answer(rs.getInt("id"), rs.getString("survey"),rs.getDate("fill_date"),Utilities.explode(rs.getString("data"),"::")));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }

}
