package modelo;

import java.util.ArrayList;

public class SurveyModel {
	private Integer id;
	private String title;
	private Integer num_questions;
	private ArrayList<String> questions;
	private ArrayList<String> questions_style;
	private String instructions;
	
	
	public SurveyModel() {
		super();
	}

	public SurveyModel(Integer id, String title, Integer num_questions, ArrayList<String> questions, ArrayList<String> questions_style, String instructions) {
		super();
		this.id = id;
		this.title = title;
		this.num_questions = num_questions;
		this.questions = questions;
		this.questions_style = questions_style;
		this.instructions = instructions;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getNum_questions() {
		return num_questions;
	}
	public void setNum_questions(Integer num_questions) {
		this.num_questions = num_questions;
	}
	public ArrayList<String> getQuestions() {
		return questions;
	}
	public void setQuestions(ArrayList<String> questions) {
		this.questions = questions;
	}
	public ArrayList<String> getQuestions_style() {
		return questions_style;
	}
	public void setQuestions_style(ArrayList<String> questions_style) {
		this.questions_style = questions_style;
	}
	public String getInstructions() {
		return instructions;
	}
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	@Override
	public String toString() {
		return "SurveyModel [id=" + id + ", title=" + title + ", num_questions=" + num_questions + ", questions="
				+ questions + "]";
	}
	
}
