package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import modelo.*;
import utility.Utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;

/**
 * Servlet implementation class AdminServlet
 */
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Gson gson = new Gson();
		SurveysDAO exDAO = new SurveysDAO();
		SurveyModelsDAO svDAO = new SurveyModelsDAO();
		AnswersDAO ansDAO = new AnswersDAO();
		ArrayList<Survey> lista = exDAO.readAll();
		JSONObject end = new JSONObject();
		JSONArray midlist = new JSONArray();
		for(Survey ex : lista) {
			ArrayList<String> item = new ArrayList<>();
			item.add(ex.getId());
			item.add(ex.getDescriptor());
			item.add(svDAO.read(ex.getSurvey_model()).getTitle());
			item.add(ansDAO.getAnswersToSurvey(ex.getId()) +" respuestas registradas");
			String modalButton = "<button type='button' class='btn btn-info btn-export'  id='"+ex.getId()+"'>Exportar</button>"+
								 "<button style='margin-left:3px' type='button' class='btn btn-danger' data-toggle='modal' data-target='#deleteModal' data-id='"+ex.getId()+"'>Borrar</button>";
			item.add(modalButton);
			midlist.put(item);
		}
		end.put("data",midlist);
		response.getWriter().append(end.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Logger.getLogger(this.getClass().getName()).log(Level.INFO, "Entro en el post", "");
	}

}
