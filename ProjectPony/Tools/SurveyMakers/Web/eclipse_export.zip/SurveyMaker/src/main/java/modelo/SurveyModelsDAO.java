package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import utility.Utilities;

public class SurveyModelsDAO {
	
	private DataSource ds = null;

	public SurveyModelsDAO() {
		InitialContext initContext;
		try {
			initContext = new InitialContext();
			ds = (DataSource) initContext.lookup("java:/comp/env/jdbc/SurveyMakerDB");
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
	}
	
	public int insert(SurveyModel model) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("INSERT INTO survey_models (title, num_questions, questions, questions_style, instructions) VALUES (?,?,?,?,?)");
			ps.setString(1, model.getTitle());
			ps.setInt(2, model.getNum_questions());
			ps.setString(3, Utilities.implode(model.getQuestions(),"::"));
			ps.setString(4, Utilities.implode(model.getQuestions_style(),"::"));
			ps.setString(5, model.getInstructions());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
	
	public int update(SurveyModel model) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("UPDATE survey_models SET title = ?, num_questions = ?, questions = ?, questions_style = ? WHERE id = ?");
			ps.setString(1, model.getTitle());
			ps.setInt(2, model.getNum_questions());
			ps.setString(3, Utilities.implode(model.getQuestions(),"::"));
			ps.setString(4, Utilities.implode(model.getQuestions_style(),"::"));
			ps.setInt(5, model.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
    
	public int delete(SurveyModel model) {
    	int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("DELETE FROM survey_models WHERE id = ?");
			ps.setInt(1, model.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
    }
	
    public SurveyModel read (int id) {
    	SurveyModel result = null;
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM survey_models WHERE id=?");
    		ps.setInt(1, id);
    		ResultSet rs = ps.executeQuery();
    		if (rs.next()) {
    			result = new SurveyModel(rs.getInt("id"), rs.getString("title"),rs.getInt("num_questions"),Utilities.explode(rs.getString("questions"),"::"),Utilities.explode(rs.getString("questions_style"),"::"),rs.getString("instructions"));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public ArrayList<SurveyModel> readAll () {
    	ArrayList<SurveyModel> result = new ArrayList<>();
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM survey_models");
    		ResultSet rs = ps.executeQuery();
    		while (rs.next()) {
    			result.add(new SurveyModel(rs.getInt("id"), rs.getString("title"),rs.getInt("num_questions"),Utilities.explode(rs.getString("questions"),"::"),Utilities.explode(rs.getString("questions_style"),"::"),rs.getString("instructions")));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }

}
