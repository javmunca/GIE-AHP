package utility;

import java.util.ArrayList;
import java.util.Arrays;

import modelo.ConfigurationsDAO;

public class Utilities {
	public static String implode(ArrayList<String> array, String glue) {
        return implode(glue, array.stream().toArray(String[]::new));
    }
	public static String implode(String glue, String[] array) {
        StringBuilder sb = new StringBuilder();
        boolean f = true;
        for (String a : array) {
            if (f) {
                f = false;
            } else {
                sb.append(glue);
            }
            sb.append(a);
        }
        return sb.toString();
    }
	
	public static ArrayList<String> explode (String input, String separator) {
		ArrayList<String> result = new ArrayList<String>(Arrays.asList(input.split(separator)));
		return result;
	}
	
	public static String getSetting(String setting_name) {
		ConfigurationsDAO confDAO = new ConfigurationsDAO();
		return confDAO.read(setting_name).getSetting_value();
	}
	
	public static String generateRandomString(int tam) {
		String theAlphaNumericS;
        StringBuilder builder;
        
        theAlphaNumericS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"; 

        //create the StringBuffer
        builder = new StringBuilder(tam); 

        for (int m = 0; m < tam; m++) {

            // generate numeric
            int myindex 
                = (int)(theAlphaNumericS.length() 
                        * Math.random()); 

            // add the characters
            builder.append(theAlphaNumericS 
                        .charAt(myindex)); 
        } 

        return builder.toString(); 
	}
}
