package modelo;

import java.util.ArrayList;

public class Experiment {
	private Integer id;
	private String title;
	private ArrayList<String> surveys;
	private ArrayList<String> answers;
	
	
	public Experiment() {
		super();
	}
	
	public Experiment(Integer id, String title, ArrayList<String> surveys, ArrayList<String> answers) {
		super();
		this.id = id;
		this.title = title;
		this.surveys = surveys;
		this.answers = answers;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public ArrayList<String> getSurveys() {
		return surveys;
	}

	public void setSurveys(ArrayList<String> surveys) {
		this.surveys = surveys;
	}

	public ArrayList<String> getAnswers() {
		return answers;
	}

	public void setAnswers(ArrayList<String> answers) {
		this.answers = answers;
	}

	@Override
	public String toString() {
		return "Experiment [id=" + id + ", surveys=" + surveys + ", answers=" + answers + "]";
	}	
}
