package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import modelo.*;
import modelo.ExperimentsDAO;
import utility.Encryption;
import utility.Utilities;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Servlet implementation class IndexServlet
 */
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		this.doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Encryption cip = new Encryption();
		String code = request.getParameter("code");
		request.setAttribute("code",code);
		RequestDispatcher dispatcher;
		String cript_code = cip.encriptar(code);

		if (cript_code.equals(Utilities.getSetting("admin_password"))) {
			dispatcher = getServletContext().getRequestDispatcher("/admin/admin.jsp");

		}
		else {
			SurveysDAO surDAO = new SurveysDAO();
			if (surDAO.exists(code)) {
				Survey surv = surDAO.read(code);
				SurveyModelsDAO smDAO = new SurveyModelsDAO();
				SurveyModel sm = smDAO.read(surv.getSurvey_model());
				request.setAttribute("survey",surv);
				request.setAttribute("surveyModel", sm);
				dispatcher = getServletContext().getRequestDispatcher("/user/user.jsp");
			}
			else {
				dispatcher = getServletContext().getRequestDispatcher("/user/notfound.jsp");
			}
		}
		dispatcher.forward(request, response);
	}

}
