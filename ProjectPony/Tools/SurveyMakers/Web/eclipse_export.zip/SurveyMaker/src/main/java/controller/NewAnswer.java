package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import modelo.*;
import utility.Utilities;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Servlet implementation class NewAnswer
 */
public class NewAnswer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewAnswer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AnswersDAO exDAO = new AnswersDAO();
		
		String code = request.getParameter("code");
		Date fill_date = new Date(System.currentTimeMillis());
		ArrayList <String> data = new ArrayList<>();
		int numQuestions = Integer.valueOf(request.getParameter("num_questions"));
		
		for(int i=0; i<numQuestions; i++) {
			data.add(request.getParameter("q-"+i));
		}
		
		Answer result = new Answer(0,code,fill_date,data);
		exDAO.insert(result);
		
		response.sendRedirect(request.getContextPath() + "/user/thanks.jsp");
		
	}

}
