package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import utility.Utilities;

public class ExperimentsDAO {
	
	private DataSource ds = null;

	public ExperimentsDAO() {
		InitialContext initContext;
		try {
			initContext = new InitialContext();
			ds = (DataSource) initContext.lookup("java:/comp/env/jdbc/SurveyMakerDB");
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
	}
	
	public int insert(Experiment experiment) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("INSERT INTO experiments (title, surveys, answers) VALUES (?,?,?)");
			ps.setString(1, experiment.getTitle());
			ps.setString(2, Utilities.implode(experiment.getSurveys(),"::"));
			ps.setString(3, Utilities.implode(experiment.getAnswers(),"::"));
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
	
	public int update(Experiment experiment) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("UPDATE experiments SET title = ?, surveys = ?, answers = ? WHERE id = ?");
			ps.setString(1, experiment.getTitle());
			ps.setString(2, Utilities.implode(experiment.getSurveys(),"::"));
			ps.setString(3, Utilities.implode(experiment.getAnswers(),"::"));
			ps.setInt(4, experiment.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
    
	public int delete(Experiment experiment) {
    	int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("DELETE FROM experiments WHERE id = ?");
			ps.setInt(1, experiment.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
    }
	
    public Experiment read (int id) {
    	Experiment result = null;
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM experiments WHERE id=?");
    		ps.setInt(1, id);
    		ResultSet rs = ps.executeQuery();
    		if (rs.next()) {
    			result = new Experiment(rs.getInt("id"), rs.getString("title"), Utilities.explode(rs.getString("surveys"),"::"),Utilities.explode(rs.getString("answers"),"::"));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public ArrayList<Experiment> readAll () {
    	ArrayList<Experiment> result = new ArrayList<>();
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM experiments");
    		ResultSet rs = ps.executeQuery();
    		while (rs.next()) {
    			result.add(new Experiment(rs.getInt("id"), rs.getString("title"), Utilities.explode(rs.getString("surveys"),"::"),Utilities.explode(rs.getString("answers"),"::")));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }

}
