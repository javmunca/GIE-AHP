package modelo;

import java.util.ArrayList;

public class Configuration {
	private String setting_name;
	private String setting_value;
	
	
	public Configuration() {
		super();
	}

	public Configuration(String setting_name, String setting_value) {
		super();
		this.setting_name = setting_name;
		this.setting_value = setting_value;
	}


	public String getSetting_name() {
		return setting_name;
	}


	public void setSetting_name(String setting_name) {
		this.setting_name = setting_name;
	}


	public String getSetting_value() {
		return setting_value;
	}


	public void setSetting_value(String setting_value) {
		this.setting_value = setting_value;
	}

	@Override
	public String toString() {
		return "Configuration [setting_name=" + setting_name + ", setting_value=" + setting_value + "]";
	}
	
}
