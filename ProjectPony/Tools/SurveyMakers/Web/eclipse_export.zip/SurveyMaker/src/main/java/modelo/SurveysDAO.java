package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import utility.Utilities;

public class SurveysDAO {
	
	private DataSource ds = null;

	public SurveysDAO() {
		InitialContext initContext;
		try {
			initContext = new InitialContext();
			ds = (DataSource) initContext.lookup("java:/comp/env/jdbc/SurveyMakerDB");
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
	}
	
	public int insert(Survey survey) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("INSERT INTO surveys (id, survey_model, descriptor) VALUES (?,?,?)");
			ps.setString(1, survey.getId());
			ps.setInt(2, survey.getSurvey_model());
			ps.setString(3, survey.getDescriptor());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
	
	public int update(Survey survey) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("UPDATE surveys SET survey_model = ?, descriptor = ? WHERE id = ?");
			ps.setInt(1, survey.getSurvey_model());
			ps.setString(2, survey.getDescriptor());
			ps.setString(3, survey.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
    
	public int delete(Survey survey) {
    	int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("DELETE FROM surveys WHERE id = ?");
			ps.setString(1, survey.getId());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
    }
	
	public int delete(String id) {
    	int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("DELETE FROM surveys WHERE id = ?");
			ps.setString(1,id);
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
    }
	
    public Survey read (String id) {
    	Survey result = null;
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM surveys WHERE id=?");
    		ps.setString(1, id);
    		ResultSet rs = ps.executeQuery();
    		if (rs.next()) {
    			result = new Survey(rs.getString("id"), rs.getInt("survey_model"), rs.getString("descriptor"));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public boolean exists (String id) {
    	boolean result = false;
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM surveys WHERE id=?");
    		ps.setString(1, id);
    		ResultSet rs = ps.executeQuery();
    		if (rs.next()) {
    			result = true;		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public ArrayList<Survey> readAll () {
    	ArrayList<Survey> result = new ArrayList<>();
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM surveys");
    		ResultSet rs = ps.executeQuery();
    		while (rs.next()) {
    			result.add(new Survey(rs.getString("id"), rs.getInt("survey_model"), rs.getString("descriptor")));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }

}
