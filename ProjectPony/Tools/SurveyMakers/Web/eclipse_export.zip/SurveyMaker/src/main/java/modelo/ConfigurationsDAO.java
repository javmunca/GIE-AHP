package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import utility.Utilities;

public class ConfigurationsDAO {
	
	private DataSource ds = null;

	public ConfigurationsDAO() {
		InitialContext initContext;
		try {
			initContext = new InitialContext();
			ds = (DataSource) initContext.lookup("java:/comp/env/jdbc/SurveyMakerDB");
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
	}
	
	public int insert(Configuration conf) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("INSERT INTO configurations (setting_name, setting_value) VALUES (?,?)");
			ps.setString(1, conf.getSetting_name());
			ps.setString(2, conf.getSetting_value());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
	
	public int update(Configuration conf, String oldSettingName) {
		int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("UPDATE configurations SET setting_name = ?, setting_value = ? WHERE setting_name = ?");
			ps.setString(1, conf.getSetting_name());
			ps.setString(2, conf.getSetting_value());
			ps.setString(3, oldSettingName);
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
	}
    
	public int delete(Configuration conf) {
    	int result = 0;
		try {
			Connection cn = ds.getConnection();
			PreparedStatement ps = cn.prepareStatement("DELETE FROM configurations WHERE setting_name = ?");
			ps.setString(1, conf.getSetting_value());
			result = ps.executeUpdate();
			ps.close();
			cn.close();
		}catch (Exception e) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
		}
		return result;
    }
	
    public Configuration read (String setting_name) {
    	Configuration result = null;
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM configurations WHERE setting_name=?");
    		ps.setString(1, setting_name);
    		ResultSet rs = ps.executeQuery();
    		if (rs.next()) {
    			result = new Configuration(rs.getString("setting_name"), rs.getString("setting_value"));
			}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }
    
    public ArrayList<Configuration> readAll () {
    	ArrayList<Configuration> result = new ArrayList<>();
    	try {
    		Connection cn = ds.getConnection();
    		PreparedStatement ps = cn.prepareStatement("SELECT * FROM configurations");
    		ResultSet rs = ps.executeQuery();
    		while (rs.next()) {
    			result.add(new Configuration(rs.getString("setting_name"), rs.getString("setting_value")));		
    		}
    		ps.close();
			cn.close();
    	}
    	catch (Exception e) {
    		Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
    	}
    	return result;
    }

}
