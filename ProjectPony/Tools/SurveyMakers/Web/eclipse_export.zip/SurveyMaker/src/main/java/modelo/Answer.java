package modelo;

import java.sql.Date;
import java.util.ArrayList;

public class Answer {
	private Integer id;
	private String survey;
	private Date fill_date;
	private ArrayList<String> data;
	
	
	public Answer() {
		super();
	}

	public Answer(Integer id, String survey, Date fill_date, ArrayList<String> data) {
		super();
		this.id = id;
		this.survey = survey;
		this.fill_date = fill_date;
		this.data = data;
	}

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getSurvey() {
		return survey;
	}


	public void setSurvey(String survey) {
		this.survey = survey;
	}


	public Date getFill_date() {
		return fill_date;
	}


	public void setFill_date(Date fill_date) {
		this.fill_date = fill_date;
	}


	public ArrayList<String> getData() {
		return data;
	}


	public void setData(ArrayList<String> data) {
		this.data = data;
	}

}
