package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import modelo.*;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Servlet implementation class ExportServlet
 */
public class ExportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExportServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AnswersDAO ansDAO = new AnswersDAO();
		//response.getWriter().append(request.getParameter("surveyid"));
		// Obtén los datos que deseas volcar en el archivo Excel
		
		ArrayList<Answer> answers = ansDAO.readFromSurvey(request.getParameter("surveyid"));
	
	    // Crea un nuevo libro de trabajo (Workbook)
	    Workbook workbook = new XSSFWorkbook();

	    // Crea una hoja (Sheet) en el libro de trabajo
	    Sheet sheet = workbook.createSheet(request.getParameter("surveyid"));

	    CellStyle style = workbook.createCellStyle();
	    Font font = workbook.createFont();
	    font.setFontName("Arial"); // Opcional, establece una fuente que admita UTF-8
	    style.setFont(font);
	    
	    //Rellena la hoja con los datos adecuados
	    for (int i=0; i<answers.get(0).getData().size(); i++) {
	    	Row dataRow = sheet.createRow(i);
	    	Cell cell = dataRow.createCell(0);
	    	cell.setCellStyle(style);
	    	cell.setCellValue("Q"+(i+1));
	    	for (int j=0; j<answers.size(); j++) {
	    		cell = dataRow.createCell(j+1);
	    		cell.setCellStyle(style);
	    		cell.setCellValue(answers.get(j).getData().get(i));
	    	}
	    }

	    // Establece el tipo de contenido de la respuesta como 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
	    response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

	    // Establece el encabezado Content-Disposition para indicar que la respuesta debe descargarse como un archivo adjunto
	    response.setHeader("Content-Disposition", "attachment; filename=\""+request.getParameter("surveyid")+".xlsx\"");

	    // Escribe el contenido del libro de trabajo en la respuesta del servlet
	    workbook.write(response.getOutputStream());

	    // Cierra el libro de trabajo
	    workbook.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
