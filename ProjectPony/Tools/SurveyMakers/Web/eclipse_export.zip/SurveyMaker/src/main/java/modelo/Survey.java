package modelo;

import java.util.ArrayList;

public class Survey {
	private String id;
	private Integer survey_model;
	private String descriptor;
	
	
	public Survey() {
		super();
	}


	public Survey(String id, Integer survey_model, String descriptor) {
		super();
		this.id = id;
		this.survey_model = survey_model;
		this.descriptor = descriptor;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public Integer getSurvey_model() {
		return survey_model;
	}


	public void setSurvey_model(Integer survey_model) {
		this.survey_model = survey_model;
	}


	public String getDescriptor() {
		return descriptor;
	}


	public void setDescriptor(String descriptor) {
		this.descriptor = descriptor;
	}
	
	
}
